<?php
mail("turkarakshay186@gmail.com", "subject", "contents");
