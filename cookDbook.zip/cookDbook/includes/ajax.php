<?php
    require 'common.php';
    $s1 = $_REQUEST['n'];
    $select_query = "SELECT book_name, id, image FROM products WHERE book_name like '%".$s1."%' ";
    $sql = mysqli_query($con, $select_query) or die(mysqli_error($con));
    $s = "";
    while($row = mysqli_fetch_array($sql))
    {
        if(isset($_SESSION['id']))
        {
        $s = $s."<a class='link-p-colr' href='see-ad.php?id=".$row['id']."'>
		<div class='live-outer'>
            	<div class='live-img'>
                	<img src='data:image/jpg;charset=utf8;base64,".base64_encode($row['image'])."'/>
                </div>
                <div class='live-product-data'>
                	<div class='live-product-name'>
                    	<p>".$row['book_name']."</p>
                    </div>
                    
                </div>
            </div>
	</a>";
        }
        else {
            $s = $s."<a class='link-p-colr' href='#' data-toggle='modal' data-target='#myModal'>
		<div class='live-outer'>
            	<div class='live-img'>
                	<img src='data:image/jpg;charset=utf8;base64,".base64_encode($row['image'])."'/>
                </div>
                <div class='live-product-data'>
                	<div class='live-product-name'>
                    	<p>".$row['book_name']."</p>
                    </div>
                    
                </div>
            </div>
	</a>";
        }
    }
    echo $s;
   
