<div id="back-to-top"><i class="fa fa-angle-double-up"></i></div>
<footer>
    <div class="footer-content">
        <div class="row">
            <div class=" col-md-6 col-content">
                <h3><strong>About us<br></strong></h3>
                <p><em>"As the page turns..."</em></p>
                <p>We are at cook-d-book believe that everyone has a righ to read.The main purpose our website
                    is to give your visitors a glimpse into who you are as a person or a business.
                    The books are very inportant part of our lives. It stores knowledge which we keep form generation to generation.
                    And as our punchline says, we always believe in what is ahead of us. And for our better future.</p>
            </div>
            <div class="col-md-4 offset-md-2 col-content">
                <h3><strong>Follow Us On<br></strong></h3>
                <ul class="list-inline social-items col-md-6">
                    <li class="list-inline-item"><a href="#"><i class="fa fa-facebook-f icon social-icon" ></i></a></li>
                    <li class="list-inline-item"><a href="#"><i class="fa fa-linkedin icon social-icon" ></i></a></li>
                    <li class="list-inline-item"><a href="#"><i class="fa fa-twitter icon social-icon" ></i></a></li>
                    <li class="list-inline-item"><a href="#"><i class="fa fa-instagram icon social-icon" ></i></a></li>
                </ul>
            </div>
           
        </div>
    </div>
    <div class="row main-footer">
        <p class="copyright col-md-6">2021-Cook-D-Book. | Developed by <a href="#"" style="color: #4d4d4d"> PRO-Castinators</a></p>
    </div>
    
     
</footer>