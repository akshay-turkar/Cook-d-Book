<?php
$con = mysqli_connect("localhost:3308", "root", "", "cookdbook") or die(mysqli_error($con));
session_start();
?>

