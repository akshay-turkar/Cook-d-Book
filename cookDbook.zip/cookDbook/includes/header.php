<script>

function fx(str)
{
    var s1=document.getElementById("qu").value;
    var xmlhttp;
    if (str.length==0) {
        document.getElementById("livesearch").innerHTML="";
        document.getElementById("livesearch").style.border="0px";
           
            document.getElementById("livesearch").style.display="block";
            
        return;
  }
if (window.XMLHttpRequest)
  {
  xmlhttp=new XMLHttpRequest();
  }
else
  {
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("livesearch").innerHTML=xmlhttp.responseText;
	
	document.getElementById("livesearch").style.display="block";
	
    }
  }
xmlhttp.open("GET","includes/ajax.php?n="+s1,true);
xmlhttp.send();	
}
</script>
<nav class="navbar navbar-expand-md navabr-light fixed-top navigation-t">
  <!-- Brand -->
  <a class="navbar-brand" href="index.php"><img src="img/logo.png" alt="Logo" ></a>
<li class="nav item" >
            
            <form class=" form-inline search-bar" action="search.php" method="GET" >
                <div class="bk">
                    
                    <input class="  mr-sm-2 search-feild" type="text" onkeyup="fx(this.value)"
                           autocomplete="off" name="qu" id="qu" tabindex="1" placeholder="Search Books...">
<!--                    <button class="btn btn-success search-button" type="submit" tabindex="2">Search
                    <i class="fa fa-search" style="font-size: 20px;" ></i></button>-->
                    <div id="livesearch"></div>
                </div>
            </form>
            
        </li>
  <!-- Toggler/collapsibe Button -->
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
      <span class="navbar-toggler-icon"><i class="fa fa-bars" style="color: #ff471a;"></i></span>
  </button>

  <!-- Navbar links -->
  <div class="collapse navbar-collapse justify-content-center" id="collapsibleNavbar">
    <ul class="navbar-nav">
        
      <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
            Genre
          </a>
          <?php
        if(!isset($_SESSION['email_id'])){
      ?>
          <div class="dropdown-menu">
            <a class="dropdown-item" href="#" data-toggle="modal" data-target="#myModal">Action and Adventure</a>
            <a class="dropdown-item" href="#" data-toggle="modal" data-target="#myModal">Poetry</a>
            <a class="dropdown-item" href="#" data-toggle="modal" data-target="#myModal">Graphic Novel</a>
            <a class="dropdown-item" href="#" data-toggle="modal" data-target="#myModal">Thrillers</a>
            <a class="dropdown-item" href="#" data-toggle="modal" data-target="#myModal">Fantasy</a>
            <a class="dropdown-item" href="#" data-toggle="modal" data-target="#myModal">Horror</a>
            <a class="dropdown-item" href="#" data-toggle="modal" data-target="#myModal">Fiction</a>
            <a class="dropdown-item" href="#" data-toggle="modal" data-target="#myModal">Romance</a>
            <a class="dropdown-item" href="#" data-toggle="modal" data-target="#myModal">Self-Help</a>
            <a class="dropdown-item" href="#" data-toggle="modal" data-target="#myModal">Biographies</a>
            <a class="dropdown-item" href="#" data-toggle="modal" data-target="#myModal">Educational</a>
            <a class="dropdown-item" href="#" data-toggle="modal" data-target="#myModal">Other</a>
          </div>
      </li>
      
      <li class="nav-item">
          <a class="nav-link" href="#" data-toggle="modal" data-target="#myModal">Login <i class="fa fa-sign-in" style="font-size: 20px;"></i></a>
      </li>
      <?php
        }
        else{
            
      ?>
      <div class="dropdown-menu">
            <a class="dropdown-item" href="genre.php?genre=Action and Adventure" >Action and Adventure</a>
            <a class="dropdown-item" href="genre.php?genre=Poetry" >Poetry</a>
            <a class="dropdown-item" href="genre.php?genre=Graphic Novel" >Graphic Novel</a>
            <a class="dropdown-item" href="genre.php?genre=Thrillers" >Thrillers</a>
            <a class="dropdown-item" href="genre.php?genre=Fantasy" >Fantasy</a>
            <a class="dropdown-item" href="genre.php?genre=Horror" >Horror</a>
            <a class="dropdown-item" href="genre.php?genre=Fiction" >Fiction</a>
            <a class="dropdown-item" href="genre.php?genre=Romance" >Romance</a>
            <a class="dropdown-item" href="genre.php?genre=Self-Help" >Self-Help</a>
            <a class="dropdown-item" href="genre.php?genre=Biographies" >Biographies</a>
            <a class="dropdown-item" href="genre.php?genre=Educational" >Educational</a>
            <a class="dropdown-item" href="genre.php?genre=Other" >Other</a>
          </div>
      </li>
      <li class="nav-item dropdown">
          <a class="nav-link" dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">Profile <i class="fa fa-user-o" style="font-size: 20px;"></i></a>
          <div class="dropdown-menu">
              <div class="dropdown-item" style="">Hello!<br>
                  <?php
                      $email = $_SESSION['email_id'];
                      $fetch_name = "SELECT username, id FROM users WHERE email_id = '$email'";
                      $fetch_name_query = mysqli_query($con, $fetch_name) or die(mysqli_errno($con));
                      $row = mysqli_fetch_array($fetch_name_query);
                      echo "<h3><i class='fa fa-user-circle-o'></i> ".$row['username']."</h3>";
                      ?>
                  
              </div>
              <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="my-ads.php"><i class='fa fa-clone'></i> My ads</a><div class="dropdown-divider"></div>
          
            <a class="dropdown-item" href="logout.php"><i class='fa fa-sign-out'></i> Logout</a>
          </div>
          
      </li>
      <li class="nav-item">
          <a class="nav-link" href="sell-book.php" >Sell <i class="fa fa-plus" style="font-size: 20px;"></i></a>
      </li>
        <?php }?>
      
    </ul>
  </div>
</nav>
