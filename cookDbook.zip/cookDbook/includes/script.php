<script>
            var btn = $('#back-to-top');
            $(document).ready(function(){
            $(window).scroll(function(){
                  var scroll = $(window).scrollTop();
                    if (scroll > 300) {
                        
                      $(".navigation-t").css("background" , "rgba(77, 77, 77, 0.7)");
                      $(".navigation-t").css("border-bottom" , "1px solid #bfbfbf");
                      $("#back-to-top").css("display", "flex");
                    }

                    else{
                        function myFunction(x) {
                            if (x.matches) { // If media query matches
                                $(".navigation-t").css("background" , "rgba(77, 77, 77, 0.7)");
                                $(".navigation-t").css("border-bottom" , "1px solid #bfbfbf");
                            }
                            else{
                                $(".navigation-t").css("background" , "transparent");
                                $(".navigation-t").css("border-bottom" , "none");
                            }
                        }
                        var x = window.matchMedia("(max-width: 990px)");
                        myFunction(x); // Call listener function at run time
                        x.addListener(myFunction); // Attach listener function on state changes
                            
                            $("#back-to-top").css("display", "none");
                    }
                    
            })
          });
          
          btn.on('click', function(e) {
            e.preventDefault();
            $('html, body').animate({scrollTop:0}, '500');
          });
          function showpass(){
            var x = document.getElementById("unique1");
            if(x.type === "password")
            {
                x.type = "text";
                
            }else
            {
                x.type = "password";
            }
        }
        
          </script> 